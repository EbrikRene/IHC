<?php
	/*
		In this file, update lat and lng of the tracked device using GPS module
	*/
	$lat = 23.6838716;
	$lng = 73.37194090000003;
	echo '{"lat":"'.$lat.'", "lng":"'.$lng.'"}';
?>
