# Location-Tracking-using-Google-Maps-Javascript-API

<br>To find route between multiple destinations using Javascript and google maps API
To use this location tracting project, you will have to get an API Key from google: https://developers.google.com/maps/documentation/javascript/get-api-key

You will have to use a gps module to get the location and then update latitude and longitude in _location.php_ file.
<br>The _maps.html_ file continuously fetches location from _location.php_ file at intervals of 5 sec and move the marker to that position.
